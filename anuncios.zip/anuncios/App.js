import React,{ useState } from 'react';
import { View, Text, Image, Button, FlatList} from 'react-native';
import {styles} from './Styles'


function App() {


 let instrumento = [
   {id: 1, img: 'https://s3.us-east-1.amazonaws.com/michael.smserver.com.br/violino-michael-vnm49_bf4d.png', nome: 'Violino', preco: 'R$6.800'},
   {id: 2, img: 'https://gifs.eco.br/wp-content/uploads/2023/03/imagens-de-violino-png-2.png', nome: 'Violino 2', preco: 'R$5.900'},
   {id: 3, img: 'https://2.bp.blogspot.com/-FfoYZxtSP4I/WmaH9TCOJ9I/AAAAAAAADK0/NhsW0sEO5N8TRKTifyUORew1VXkNeOMIQCLcBGAs/s1600/Viola%2Bde%2Barco.png', nome: 'Viola', preco: 'R$8.500'},
   {id: 4, img: 'https://s3.us-east-1.amazonaws.com/michael.smserver.com.br/violoncello-michael-vom116_c61d.png', nome: 'Cello', preco: 'R$12.200'}
 ]
  const [feed, setFeed] = useState(instrumento)


  return(
    <View >

     <Text style={styles.titulo}>
        {'Intrumentos a venda!!'}
    </Text>
    <Text >
 
    <FlatList style={styles.container} horizontal={true} showsHorizontalScrollIndicator={true}
        data={feed}
        keyExtractor={(item) => item.id}
        renderItem={ ({item}) => <Instrumentos data={item}/>}
    />
    </Text>

    <Text style={styles.titulo}>
        {'Compre conosco!!'}
    </Text>
    

    </View>

   
  )
  
}
export default App

function Instrumentos(props){
  return(

    <View>
          <Image style={styles.imagem} source={{uri: props.data.img}}/>
          <Text style={styles.leg} > Nome: {props.data.nome} </Text>
          <Text style={styles.leg} > Preço: {props.data.preco} </Text>
     

    </View>

  );
}