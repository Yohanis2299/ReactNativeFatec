import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({


imagem:{
margin: 30,
height: 100,
width: 200,

},

leg:{
margin: 30,
textAlign:'center'


},
container:{
  margin: 10,
  borderWidth: 5,
  borderColor: 'black',
  backgroundColor: '#ccc',
  
},

    titulo:{
    marginTop: 0,
    fontSize: 30, 
    color: 'black', 
    textAlign: 'center'
  },


})
  
export {styles}