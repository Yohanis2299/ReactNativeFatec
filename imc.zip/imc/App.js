import React, { useState } from 'react';
import { View, Text, Button, TextInput, Image} from 'react-native';
import {styles} from './Styles'


export default function App(){
  const [resultado, setResultado] = useState()
  const [altura, setAltura] = useState()
  const [peso, setPeso] = useState()
  

  function verificar() {
    resultadon = (peso / (altura * altura))

    if (resultadon <= 18.5)
      setResultado('Abaixo do peso')
    else if (resultadon <= 24.9)
      setResultado('Peso Normal')
    else if (resultadon <= 29.9)
      setResultado('Sobrepeso')
    else if (resultadon <= 34.9)
      setResultado('Obesidade Grau I')
    else if (resultadon <= 39.9)
      setResultado('Obesidade Grau II')
    else
     setResultado('Obesidade Grau III ou Mórbita')
  }

  return(
    <View style={{ marginTop: 100 }}>

      <Text style={{fontSize: 20, color: 'black', textAlign: 'center'}}>
        {'Calculo de IMC'}
      </Text>

      <Image source={{uri: 'https://ichef.bbci.co.uk/news/640/cpsprodpb/15E02/production/_104620698_prmo_imc_br-nc.png'}}
       style={styles.imagem} />

      <TextInput
      style={styles.input}
      placeholder ='Peso'
      onChangeText={setPeso}
      />

      <TextInput
      style={styles.input}
      placeholder ='Altura'
      onChangeText={setAltura}
      />

      <Button color='green' title='Verificar' onPress={() => verificar ()}/>


      <Text style={{fontSize: 50, color: 'black', textAlign: 'center'}}>
        {resultado} 
      </Text>
   
    </View>
  )
}
