import React, { Component, useState } from 'react';
import { View, StyleSheet, FlatList, Text } from 'react-native';
import {styles} from './Styles'


function App(){


  let initial_feed = [
        {id: 1, vaga: 'Dev Junior', salario: 'R$ 1500,00', email: 'felipe@gmail.com'},
        {id: 2, vaga: 'Dev Senior SQL', salario: 'R$ 7500,00', email: 'gustavo@gmail.com'},
        {id: 3, vaga: 'Analista dados ', salario: 'R$ 4200,00', email: 'maria@gmail.com'},
        {id: 4, vaga: 'Dev React Native', salario: 'R$ 5600,00', email: 'joaquim@gmail.com'},
        {id: 5, vaga: 'Gerente Projetos', salario: 'R$ 9500,00', email: 'paulo@gmail.com'},
      ]


  const [feed, setFeed] = useState(initial_feed)


  return(
    <View style={styles.container}>
      <FlatList
      data={feed}
      keyExtractor={(item) => item.id}
      renderItem={ ({item}) => <Pessoa data={item}/>}
      />
    </View>
  )
}


export default App;

function Pessoa(props){
  return(
      <View style={styles.areaPessoa}>
        <Text style={styles.textoPessoa}> Vaga: {props.data.vaga} </Text>
        <Text style={styles.textoPessoa}> Salario: {props.data.salario} </Text>
        <Text style={styles.textoPessoa}> E-mail: {props.data.email} </Text>
      </View>
  );
}


