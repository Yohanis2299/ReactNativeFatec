import {StyleSheet} from 'react-native'



const styles = StyleSheet.create({

  container:{
    flex: 1
  },
  areaPessoa:{
    backgroundColor: 'grey',
    height: 200,
    marginBottom: 15
  },
  textoPessoa:{
    color: 'black',
    fontSize: 25,
    textAlign: 'center',
    padding: 10,
  },


})

export {styles}