import React, { useState } from 'react';
import { View, Text, Button, TextInput } from 'react-native';
import {styles} from './Styles'


export default function App(){
  const [resultado, setResultado] = useState()
  const [numero1, setNumero1] = useState()
  const [numero2, setNumero2] = useState()
  

  function calcular() {
    setResultado  ((numero1) * (numero2))
  }



  return(
    <View style={{ marginTop: 300 }}>

      <Text style={{fontSize: 20, color: 'black', textAlign: 'center'}}>
        {'MULTIPLICADOR DE PESSOAS'}
      </Text>

      <TextInput
      style={styles.input}
      placeholder ='Digite o primeiro numero'
      onChangeText={setNumero1}
      />

      <TextInput
      style={styles.input}
      placeholder ='Digite o segundo numero'
      onChangeText={setNumero2}
      />

      <Button color='green' title='Calcular' onPress={() => calcular()}/>


      <Text style={{fontSize: 50, color: 'black', textAlign: 'center'}}>
        {resultado}
      </Text>
   
    </View>
  )
}
