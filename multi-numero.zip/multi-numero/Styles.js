import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({

  input:{
    height: 45,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 20,
    padding: 10,
  },


})

export {styles}
