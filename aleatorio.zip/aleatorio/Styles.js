import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({

area:{
  marginTop: 100 , 
  backgroundColor: '#ccc', 
  padding: 10,

},
  input:{
    height: 45,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 20,
    padding: 10,
  },

  imagem:{
    height: 100,
    width: 300,
    marginLeft: 110,
    //justifyContent: 'center',
    //marginBottom: 10,

  },

  
titulo:{
    margin: 10,
    fontSize: 20, 
    color: 'red', 
    textAlign: 'center'
  },

  imagem:{
    height: 100,
    width: 100,
    marginLeft: 110,
    justifyContent: 'center',
    marginBottom: 10,

  },

  link:{
  textAlign:'center',
  marginBottom: 10,
  }

})

export {styles}