import {View, Text, Image, TextInput, Button} from 'react-native'
import {useState} from 'react'
import {styles} from './Styles'

export default function App(){

const nAleatorio = Math.floor(Math.random() * 11)
const [resultado, setResultado] = useState(0)

  return(

    <View style={styles.area} >
        <Text style={styles.titulo} >Jogo do Nº Alternativo</Text>

        <Image style={styles.imagem}
        source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJxny0vTXjilHLeTWr0QuxBDbMDL5JEjunwg&usqp=CAU' }}
        
      />

        <Text>Pense em um número de 0 á 10!!</Text>    

        <Button title='Descobrir' onPress={() => setResultado(nAleatorio)}/>

        <Text> Resultado: {resultado}</Text>

    </View>
  )
}

