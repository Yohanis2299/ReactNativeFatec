import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';


export default function App(){
  const [total, setTotal] = useState(0)
  

  function adicionar() {
    setTotal (total + 1)
  }

  function diminuir() {
    if (total>0)
    setTotal (total - 1)

  }

  return(
    <View style={{ marginTop: 300 }}>

      <Text style={{fontSize: 20, color: 'black', textAlign: 'center'}}>
        {'CONTADOR DE PESSOAS'}
      </Text>
      <Button color='green' title='+' onPress= {()=>adicionar()} />
      <Button color='red' title="-" onPress={() => diminuir()} />
      
      <Text style={{fontSize: 50, color: 'black', textAlign: 'center'}}>
        {total}
      </Text>
    </View>
  )
}
