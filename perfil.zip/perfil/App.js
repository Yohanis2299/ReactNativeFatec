import React, { useState } from 'react';
import { View, Text, Button, TextInput, Image, Linking} from 'react-native';
import {styles} from './Styles'


export default function App(){
  const [resultado, setResultado] = useState(0)
  const [alcool, setAlcool] = useState()
  const [gasolina, setGasolina] = useState()
  

  return(
    <View style={styles.view}>

      <Text style={{fontSize: 20, color: 'black', textAlign: 'center'}}>
        {'Meu Perfil'}
      </Text>

      <Image source={{uri: 'https://media.licdn.com/dms/image/D5603AQHSo8dTuimZ-Q/profile-displayphoto-shrink_200_200/0/1693520442240?e=1701907200&v=beta&t=cpiLCtlQx4mGFzLijGCy-4Z68-cax3jZMDvrqed0nJs'} }

       style={styles.imagem} />

      <Text style={styles.link} onPress={()=> {Linking.openURL('https://www.linkedin.com/in/yohanis-viana-machado-3234a71b1/')}}>
        {'Linkdin'}
      </Text>
      

      <Text style={styles.titulo}>
        {'Nome: Yohanis Viana Machado'}
      </Text>

      <Text style={styles.titulo}>
        {'Formação: Cursando Analise desenvolvimento Sistemas'}
      </Text>

      <Text style={styles.titulo}>
        {'Experiencia: Dev Junior Dynamics365'}
      </Text>

      <Text style={styles.titulo}>
        {'Projetos: Moura Baterias / BuschLepper'}
      </Text>



    </View>
  )
}