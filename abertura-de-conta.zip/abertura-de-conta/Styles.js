import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({

  input:{
    height: 30,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 15,
    padding: 1,
  },

    picker:{
    height: 20,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 10,
    padding: 1,
  },

  imagem:{
    height: 150,

    marginBottom: 10,
  },
  container:{
    flex:1,
    marginTop: 10,
  },

    titulo:{
    marginTop: 0,
    fontSize: 30, 
    color: 'black', 
    textAlign: 'center'
  },

      titulov2:{
    marginTop: 0,
    fontSize: 20, 
    color: 'black', 
    textAlign: 'center'
  },

  view:{
    flex:1,
    marginTop: 80,
},
  view2:{
    borderWidth: 3,
    borderColor: 'brown',
    padding: 10,
    margin: 10,
},


})

export {styles}