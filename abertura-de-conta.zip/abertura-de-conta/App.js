import { useState } from 'react';
import { View, Text, Switch,TextInput, Button} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import {styles} from './Styles'
import Slider from '@react-native-community/slider';


function App() {


  const [nome, setNome] = useState(' ')
  const [idade, setIdade] = useState(0)
  const [sexo, setSexo] = useState(' ')
  const [escolaridade, setEscolaridade] = useState(' ')
  const [limite, setLimite] = useState(0)
  const [nacionalidade, setNacionalidade] = useState(false)
  const [dataConfirm, setDataConfirm] = useState(false)

  
  function DataReturn (props)
  {
    setDataConfirm(true)
          return (
          <View >
            <Text style={styles.titulo}> Dados Do CLiente </Text>
            <Text style={styles.titulo}> Nome: {props.name} </Text>
            <Text style={styles.titulo}> Idade: {props.idade} </Text>
            <Text style={styles.titulo}> Sexo: {props.sexo} </Text>
            <Text style={styles.titulo}> Escolaridade: {props.Escolaridade} </Text>
            <Text style={styles.titulo}> Limite: {props.limite} </Text>
            <Text style={styles.titulo}> Nacionalidade: {props.nacionalidade ? 'Sim' : 'Nao'} </Text>
            
          </View>

        )
  }
  
  return (

    <View style={styles.view} >
    <View style={styles.view2}>

    <Text style={styles.titulo}>
        {'Abertura de Conta'}
    </Text>

    <TextInput
      style={styles.input}
      onChangeText={setNome}
      placeholder ='Nome'
      placeholderTextColor = 'grey'
    />

    <TextInput
      style={styles.input}
      onChangeText={setIdade}
      placeholder ='Idade'
      placeholderTextColor = 'grey'
    />

    <Text> sexo
    <Picker style={styles.picker}
      selectedValue={sexo}
      onValueChange={ (itemValue, itemIndex) => setSexo(itemValue) }
      >
        <Picker.Item key={1} value= "Selecione" label="Selecione" />
        <Picker.Item key={2} value= "Masculino" label="Masculino" />
        <Picker.Item key={3} value= "Feminino" label="Feminino" />
      </Picker>
    </Text>

    <Text > Escolaridade
    <Picker 
      selectedValue={escolaridade}
      onValueChange={ (itemValue, itemIndex) => setEscolaridade(itemValue) }
      >
        <Picker.Item key={1} value= "Selecione" label="Selecione" />
        <Picker.Item key={2} value= "Ensino Fundamental" label="Ensino Fundamental" />
        <Picker.Item key={3} value= "Superior" label= "Superior" />
        <Picker.Item key={4} value= "Mestrado" label="Mestrado" />
        <Picker.Item key={5} value= "Doutorado" label="Doutorado" />
      </Picker>
    </Text>

    <Text style={styles.titulov2}>
        {'Limite de Valor'}
    </Text>

    <Slider
                value={limite}
                onValueChange={(value) => setLimite(value)}
                minimumValue={0}
                maximumValue={5000}
                step={0.01}
    />
    <Text style={styles.titulov2}>
        R$ {limite.toFixed(2)}
    </Text>

    <Text style={styles.titulov2}>
        Brasileiro: Não 
         <Switch
      value={nacionalidade}
      onValueChange={ (value) => setNacionalidade(value) }
      alueChange={ (value) => setNacionalidade(value) }
      thumbColor='black'
      />
      Sim
    </Text>

    <Button title= "Confirmar" onPress={DataReturn}/>

    {dataConfirm && (
      <DataReturn name={nome}
                  idade={idade}
                  sexo={sexo}
                  escolaridade={escolaridade}
                  limite={limite}
                  nacionalidade={nacionalidade}/>
    )}
    </View>
    </View>
  );
}


export default App