import React, { useState } from 'react';
import { View, Text, Button, TextInput, Image} from 'react-native';
import {styles} from './Styles'


export default function App(){
  const [resultado, setResultado] = useState(0)
  const [alcool, setAlcool] = useState()
  const [gasolina, setGasolina] = useState()
  

  function verificar() {
    r = alcool /gasolina
    if (r <= 0.7)
    setResultado('Melhor Alcool')
    else
    setResultado('Melhor Gasolina')
  }

  return(
    <View style={{ marginTop: 100 }}>

      <Text style={{fontSize: 20, color: 'black', textAlign: 'center'}}>
        {'Alcool ou Gasosa?'}
      </Text>

      <Image source={{uri: 'https://th.bing.com/th/id/OIP.1t6wcJs-eu999M8bMgVVxgAAAA?pid=ImgDet&rs=1'}}
       style={styles.imagem} />

      <TextInput
      style={styles.input}
      placeholder ='Digite o preço do Alcool'
      onChangeText={setAlcool}
      />

      <TextInput
      style={styles.input}
      placeholder ='Digite o preço da Gasolina'
      onChangeText={setGasolina}
      />

      <Button color='green' title='Verificar' onPress={() => verificar ()}/>


      <Text style={{fontSize: 50, color: 'black', textAlign: 'center'}}>
        {resultado}
      </Text>
   
    </View>
  )
}
